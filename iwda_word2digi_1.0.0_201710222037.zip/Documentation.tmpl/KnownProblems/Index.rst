﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _known-problems:

Known Problems
==============

Say where bugs can be reported / followed up. Is it a
`bug tracker <http://forge.typo3.org/projects/typo3cms-doc-official-extension-template/issues>`_?
Use this section for informing about any type of of problem
that are not necessarily named in the bug tracker such as performance issues, ...
